# main.py
import os
from estructura import (
    cargar_diccionario_txt,
    agregar_linea_txt,
    construir_trie_desde_lista
)
from DLS import dls_iterativo



BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ruta_txt = os.path.join(BASE_DIR, "diccionario.txt")

def cargar_todo(ruta_txt):
    dicc, palabras = cargar_diccionario_txt(ruta_txt)
    trie = construir_trie_desde_lista(palabras)
    return dicc, palabras, trie

def buscar_palabra(trie, dicc, palabra, limite):
    objetivo = trie.find_terminal_id(palabra)
    inicio = trie.root.id
    grafo = trie.get_graph()
    ok, path, visitados, t = dls_iterativo(grafo, inicio, objetivo, limite)
    print("\n=== Resultado DLS ===")
    print(f"Palabra objetivo: {palabra}")
    print(f"Límite: {limite}")
    print(f"Tiempo: {t:.6f} s")
    print(f"Nodos visitados: {len(visitados)}")
    if path:
        print(f"Ruta (ids): {path}")
        print(f"Ruta como palabra: '{trie.path_to_word(path)}'")
        print(f"Códigos ASCII: {trie.path_to_ascii(path)}")
    else:
        print("No se encontró una ruta dentro del límite.")
    print(f"¿Encontrado exactamente?: {'SÍ' if ok else 'NO'}")
    if ok:
        significado = dicc.get(palabra)
        if significado:
            print(f"\nSignificado: {significado}")
        else:
            print("\n(La palabra está en el trie, pero no se halló su significado en el diccionario.)")

def menu():
    print("============== DLS (Búsqueda de Profundidad Limitada) ==============")
    print("1. Agregar palabra:significado al archivo")
    print("2. Buscar palabra (DLS)")
    print("3. Salir")
    try:
        return int(input("Opción: ").strip())
    except:
        return 0

def main():

    if not os.path.exists(ruta_txt):
        print(f"ADVERTENCIA: No se encontró {ruta_txt}. Crea el archivo con líneas 'Palabra:Significado'.")
        return

    dicc, palabras, trie = cargar_todo(ruta_txt)

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        opc = menu()

        if opc == 1:
            palabra = input("Nueva palabra: ").strip()
            significado = input("Significado: ").strip()
            if not palabra or not significado:
                print("[OK] Agregada y cargada en memoria.")
                print("[X] Entrada inválida.")
                continue
            agregar_linea_txt(ruta_txt, palabra, significado)
            dicc[palabra] = significado
            trie.insert(palabra)
            print("✅ Agregada y cargada en memoria.")
            input("Enter para continuar...")

        elif opc == 2:
            palabra = input("Palabra a buscar: ").strip()
            try:
                limite = int(input("Límite de profundidad (sug: len(palabra)+1): ").strip())
            except:
                limite = max(2, len(palabra)+1)
            buscar_palabra(trie, dicc, palabra, limite)
            input("\nEnter para continuar...")

        elif opc == 3:
            print("Saliendo...")
            break

        else:
            print("Opción no válida.")
            input("Enter para continuar...")

if __name__ == "__main__":
    main()

# pila.py
class Pila:
    def __init__(self):
        self._items = []

    def push(self, x):
        self._items.append(x)

    def pop(self):
        if self.esta_vacia():
            return None
        return self._items.pop()

    def peek(self):
        if self.esta_vacia():
            return None
        return self._items[-1]

    def esta_vacia(self):
        return len(self._items) == 0

    def __len__(self):
        return len(self._items)

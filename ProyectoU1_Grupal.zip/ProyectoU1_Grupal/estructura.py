# estructura.py
from collections import defaultdict

class TrieNode:
    __slots__ = ("id", "code", "children", "terminal")
    def __init__(self, node_id, code=None):
        self.id = node_id
        self.code = code              # ord(caracter) o None si es raíz
        self.children = {}            # {ord(char): TrieNode}
        self.terminal = False         # fin de palabra

class TrieASCII:
    def __init__(self):
        self.nodes = []
        self.root = self._new_node(code=None)
        self.graph = defaultdict(list)  # id -> [ids hijos]

    def _new_node(self, code):
        nid = len(self.nodes)
        self.nodes.append(TrieNode(nid, code))
        return self.nodes[nid]

    def insert(self, palabra: str):
        node = self.root
        for ch in palabra:
            c = ord(ch)
            if c not in node.children:
                nuevo = self._new_node(c)
                node.children[c] = nuevo
                self.graph[node.id].append(nuevo.id)
            node = node.children[c]
        node.terminal = True
        return node.id

    def find_terminal_id(self, palabra: str):
        node = self.root
        for ch in palabra:
            c = ord(ch)
            if c not in node.children:
                return None
            node = node.children[c]
        return node.id if node.terminal else None

    def get_graph(self):
        return dict(self.graph)

    def path_to_word(self, path_ids):
        chars = []
        for nid in path_ids:
            code = self.nodes[nid].code
            if code is not None:
                chars.append(chr(code))
        return "".join(chars)

    def path_to_ascii(self, path_ids):
        return [self.nodes[nid].code for nid in path_ids if self.nodes[nid].code is not None]


# ---------- Utilidades de archivo (.txt "Palabra:Significado") ----------
def cargar_diccionario_txt(ruta_txt: str):
    """
    Devuelve (diccionario, lista_palabras) donde:
      - diccionario: {palabra: significado}
      - lista_palabras: lista de palabras en orden de aparición
    """
    dicc = {}
    palabras = []
    with open(ruta_txt, "r", encoding="utf-8") as f:
        for linea in f:
            linea = linea.strip()
            if not linea:
                continue
            # dividir SOLO en el primer ':'
            if ":" not in linea:
                continue
            palabra, significado = linea.split(":", 1)
            palabra = palabra.strip()
            significado = significado.strip()
            if palabra and significado:
                # en caso de duplicados, la última línea prevalece
                dicc[palabra] = significado
                palabras.append(palabra)
    return dicc, palabras


def agregar_linea_txt(ruta_txt: str, palabra: str, significado: str):
    with open(ruta_txt, "a", encoding="utf-8") as f:
        # agrega nueva línea si el archivo no termina con salto
        f.write(f"\n{palabra}:{significado}")


def construir_trie_desde_lista(palabras):
    trie = TrieASCII()
    for w in palabras:
        trie.insert(w)
    return trie

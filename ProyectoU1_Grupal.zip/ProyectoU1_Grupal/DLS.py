# dls.py
import time
from pila import Pila

def dls_iterativo(grafo, inicio_id, objetivo_id, limite):
    """
    Depth-Limited Search iterativo con pila explícita.
    - grafo: dict id -> [ids hijos]
    - inicio_id: id del nodo raíz
    - objetivo_id: id del nodo terminal buscado
    - limite: profundidad máxima (root cuenta como 0)
    Retorna: (encontrado(bool), path_ids(list), visitados(set), tiempo_segundos)
    """
    t0 = time.time()
    visitados = set()
    if objetivo_id is None or limite < 0:
        return False, None, visitados, time.time()-t0

    # pila de tuplas: (nodo_id, profundidad, camino_hasta_aqui)
    pila = Pila()
    pila.push((inicio_id, 0, [inicio_id]))

    while not pila.esta_vacia():
        nodo, prof, path = pila.pop()
        visitados.add(nodo)

        if nodo == objetivo_id:
            return True, path, visitados, time.time()-t0

        if prof == limite:
            continue

        # hijos en orden normal; para DFS correcta (LIFO), apilamos en reversa
        hijos = grafo.get(nodo, [])
        for h in reversed(hijos):
            if h not in path:  # evita ciclos en grafos generales; en trie no hay
                pila.push((h, prof+1, path + [h]))

    return False, None, visitados, time.time()-t0
